import styled from "styled-components";

export const ToolbarContainer = styled.div`
  padding: 0px 24px;
`;
