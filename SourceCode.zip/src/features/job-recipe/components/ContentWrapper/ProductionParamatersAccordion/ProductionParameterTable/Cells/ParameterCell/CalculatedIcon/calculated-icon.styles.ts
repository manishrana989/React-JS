import styled from "styled-components";

export const Container = styled.div`
  position: relative;
`;

export const CalcIcon = styled.img`
  height: 28px;
`;
