export const PRODUCTION_PARAMETERS_DRAWER_ID = "production-parameters";
