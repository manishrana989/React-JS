import styled from "styled-components";

export const UploadButtonContainer = styled.div`
  position: relative;
`;
