export const GetSyncFileStatus = "GetSyncFileStatus";
export const GetImportSyncFields = "GetImportSyncFields";
export const UpdateSyncMappingForInterface = "UpdateSyncMappingForInterface";
export const ValidateSyncMappingForInterface =
  "ValidateSyncMappingForInterface";
export const UploadSyncFile = "UploadSyncFile";
export const GetS3FileObject = "GetS3FileObject";
export const GetS3LogFileObject = "GetS3LogFileObject";
