export interface RadioButtonInterface {
  IsActive: boolean;
}
