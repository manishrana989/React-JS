export interface ProductPreviewInterface {
  TitleText: string;
  url: string;
}
