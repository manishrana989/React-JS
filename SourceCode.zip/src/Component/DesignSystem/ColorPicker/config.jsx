const config = {
  squareSize: 200,
  barSize: 16,
  crossSize: 32,
  inputSize: 88,
  delay: 100,
  colorsSize: 40,
};

export default config;
