import { SpinnerContainer } from "./spinner.styles";

const Spinner = () => {
  return <SpinnerContainer />;
};

export default Spinner;
