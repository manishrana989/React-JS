import styled from "styled-components";

export const SearchWrapper = styled.div`
  padding: 7.5px 16px;
  position: relative;
  z-index: 99;
`;
