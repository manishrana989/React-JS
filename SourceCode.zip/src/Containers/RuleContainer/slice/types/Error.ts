export enum ErrorType {
  RESPONSE_ERROR = 1,
  NO_DATA = 2,
  FAIL_404 = 3,
}
